package model;

public class Secretary extends User {

	public Secretary() {
		super();
	}

	public Secretary(String Name, String PersonalNumber, String UserName, String Password) {
		super(Name, PersonalNumber, UserName, Password);
	}

}
