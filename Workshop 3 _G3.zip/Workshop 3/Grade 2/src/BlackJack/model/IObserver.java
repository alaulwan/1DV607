package BlackJack.model;

public interface IObserver {
	public void PlayerGetNewCard();
}
